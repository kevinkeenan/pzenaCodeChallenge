﻿using CsvHelper.Configuration;
using PzenaCodeChallenge.Models;

namespace PzenaCodeChallenge.Helpers
{
    public class CaseInsensitivePriceMap : ClassMap<Price>
    {
        public CaseInsensitivePriceMap()
        {
            // Map properties ignoring case
            Map(m => m.Ticker).Name("Ticker", "ticker", "TICKER");
            Map(m => m.Date).Name("Date", "date", "DATE");
            Map(m => m.OpenPrice).TypeConverter<CustomDecimalConverter>().Name("Open", "open", "OPEN");
            Map(m => m.HighPrice).TypeConverter<CustomDecimalConverter>().Name("High", "high", "HIGH");
            Map(m => m.LowPrice).TypeConverter<CustomDecimalConverter>().Name("Low", "low", "LOW");
            Map(m => m.ClosePrice).TypeConverter<CustomDecimalConverter>().Name("Close", "close", "CLOSE");
            Map(m => m.Volume).TypeConverter<CustomDecimalConverter>().Name("Volume", "volume", "VOLUME");
            Map(m => m.CloseAdjusted).TypeConverter<CustomDecimalConverter>().Name("CloseAdj", "closeadj", "CLOSEADJ");
            Map(m => m.CloseUnadjusted).TypeConverter<CustomDecimalConverter>().Name("CloseUnadj", "closeunadj", "CLOSEUNADJ");
            Map(m => m.LastUpdated).Name("LastUpdated", "lastupdated", "LASTUPDATED");
        }
    }
}
