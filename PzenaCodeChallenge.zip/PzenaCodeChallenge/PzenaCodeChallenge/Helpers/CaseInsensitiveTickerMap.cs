﻿using CsvHelper.Configuration;
using PzenaCodeChallenge.Models;

namespace PzenaCodeChallenge.Helpers
{
    public class CaseInsensitiveTickerMap : ClassMap<Ticker>
    {
        public CaseInsensitiveTickerMap()
        {
            // Map properties with multiple values for name
            Map(m => m.Table).Name("Table", "table", "TABLE");
            Map(m => m.TickerSymbol).Name("Ticker", "ticker", "TICKER");
            Map(m => m.PermaTicker).Name("Permaticker", "permaticker", "PERMATICKER");
            Map(m => m.Name).Name("Name", "name", "NAME");
            Map(m => m.Exchange).Name("Exchange", "exchange", "EXCHANGE");
            Map(m => m.IsDelisted).Name("IsDelisted", "isdelisted", "ISDELISTED");
            Map(m => m.Category).Name("Category", "category", "CATEGORY");
            Map(m => m.Cusips).Name("CUSIPs", "cusips", "CUSIPS");
            Map(m => m.SicCode).Name("SicCode", "siccode", "SICCODE");
            Map(m => m.SicSector).Name("SicSector", "sicsector", "SICSECTOR");
            Map(m => m.SicIndustry).Name("SicIndustry", "sicindustry", "SICINDUSTRY");
            Map(m => m.FamaSector).Name("FamaSector", "famasector", "FAMASECTOR");
            Map(m => m.FamaIndustry).Name("FamaIndustry", "famaindustry", "FAMAINDUSTRY");
            Map(m => m.Sector).Name("Sector", "sector", "SECTOR");
            Map(m => m.Industry).Name("Industry", "industry", "INDUSTRY");
            Map(m => m.ScaleMarketCap).Name("ScaleMarketCap", "scalemarketcap", "SCALEMARKETCAP");
            Map(m => m.ScaleRevenue).Name("ScaleRevenue", "scalerevenue", "SCALEREVERENUE");
            Map(m => m.RelatedTickers).Name("RelatedTickers", "relatedtickers", "RELATEDTICKERS");
            Map(m => m.Currency).Name("Currency", "currency", "CURRENCY");
            Map(m => m.Location).Name("Location", "location", "LOCATION");
            Map(m => m.LastUpdated).Name("LastUpdated", "lastupdated", "LASTUPDATED");
            Map(m => m.FirstAdded).Name("FirstAdded", "firstadded", "FIRSTADDED");
            Map(m => m.FirstPriceDate).Name("FirstPriceDate", "firstpricedate", "FIRSTPRICEDATE");
            Map(m => m.LastPriceDate).Name("LastPriceDate", "lastpricedate", "LASTPRICEDATE");
            Map(m => m.FirstQuarter).Name("FirstQuarter", "firstquarter", "FIRSTQUARTER");
            Map(m => m.LastQuarter).Name("LastQuarter", "lastquarter", "LASTQUARTER");
            Map(m => m.SecFilings).Name("SecFilings", "secfilings", "SECFILINGS");
            Map(m => m.CompanySite).Name("CompanySite", "companysite", "COMPANYSITE");
        }
    }
}