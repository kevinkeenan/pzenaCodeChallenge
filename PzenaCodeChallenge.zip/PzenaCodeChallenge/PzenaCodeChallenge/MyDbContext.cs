﻿using Microsoft.EntityFrameworkCore;
using PzenaCodeChallenge.Models;

namespace PzenaCodeChallenge
{
    public class MyDbContext : DbContext
    {
        public MyDbContext(DbContextOptions<MyDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Define composite key for Price entity
            modelBuilder.Entity<Price>().HasKey(p => new { p.Ticker, p.Date });
            modelBuilder.Entity<Ticker>().HasKey(t => new { t.TickerSymbol });

        }

        public DbSet<Ticker> Ticker { get; set; }

        public DbSet<Price> Price { get; set; }
    }
}
