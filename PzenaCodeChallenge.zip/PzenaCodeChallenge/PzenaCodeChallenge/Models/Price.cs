﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PzenaCodeChallenge.Models
{
    public class Price
    {
        [Key]
        [Column("Ticker")]
        public string Ticker { get; set; }

        [Key]
        [Column("Date")]
        public DateTime Date { get; set; }

        [Column("OpenPrice")]
        public decimal OpenPrice { get; set; }

        [Column("HighPrice")]
        public decimal HighPrice { get; set; }

        [Column("LowPrice")]
        public decimal LowPrice { get; set; }

        [Column("ClosePrice")]
        public decimal ClosePrice { get; set; }

        [Column("Volume")]
        public decimal Volume { get; set; }

        [Column("CloseAdjusted")]
        public decimal CloseAdjusted { get; set; }

        [Column("CloseUnadjusted")]
        public decimal CloseUnadjusted { get; set; }

        [Column("LastUpdated")]
        public DateTime LastUpdated { get; set; }
    }
}
