﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PzenaCodeChallenge.Models
{
    public class Ticker
    {
        public string Table { get; set; }
        public string PermaTicker { get; set; }
        [Key]
        public string TickerSymbol { get; set; }
        public string Name { get; set; }
        public string Exchange { get; set; }
        public string IsDelisted { get; set; }
        public string Category { get; set; }
        public string? Cusips { get; set; }
        public int? SicCode { get; set; }
        public string? SicSector { get; set; }
        public string? SicIndustry { get; set; }
        public string? FamaSector { get; set; }
        public string? FamaIndustry { get; set; }
        public string? Sector { get; set; }
        public string? Industry { get; set; }
        public string? ScaleMarketCap { get; set; }
        public string? ScaleRevenue { get; set; }
        public string? RelatedTickers { get; set; }
        public string Currency { get; set; }
        public string? Location { get; set; }
        public DateTime LastUpdated { get; set; }
        public DateTime FirstAdded { get; set; }
        public DateTime FirstPriceDate { get; set; }
        public DateTime LastPriceDate { get; set; }
        public DateTime? FirstQuarter { get; set; }
        public DateTime? LastQuarter { get; set; }
        public string SecFilings { get; set; }
        public string? CompanySite { get; set; }
    }
}
