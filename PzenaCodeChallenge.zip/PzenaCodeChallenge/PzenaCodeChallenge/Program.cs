﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using PzenaCodeChallenge.Data.Repositories;

namespace PzenaCodeChallenge
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string connectionString = @"Server=(localdb)\Local;Database=pzena;Trusted_Connection=True;MultipleActiveResultSets=true";
            //TODO: GET FROM APPSETTINGS

            var optionsBuilder = new DbContextOptionsBuilder<MyDbContext>();
            optionsBuilder.UseSqlServer(connectionString);

            var dbOptions = optionsBuilder.Options;
            var dbContext = new MyDbContext(dbOptions);
            var priceRepository = new PriceRepository(dbContext);
            var tickerRepository = new TickerRepository(dbContext);
            var fileImporter = new FileImporter(priceRepository, tickerRepository);

            //TODO: implement donwload and extract of zip file
            try
            {
                var pricesFilePath = "C:\\Users\\kkeenan\\Documents\\PzenaCodeChallenge\\PzenaCodeChallenge\\Data\\PricesSmall.csv";
                fileImporter.ImportPricesFromCsv(pricesFilePath);
                var tickersFilePath = "C:\\Users\\kkeenan\\Documents\\PzenaCodeChallenge\\PzenaCodeChallenge\\Data\\TickersSmall.csv";
                fileImporter.ImportTickersFromCsv(tickersFilePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error upserting to local DB: " + ex.Message);
            }

        }
    }
}
