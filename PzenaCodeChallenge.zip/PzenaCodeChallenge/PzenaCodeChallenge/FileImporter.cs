﻿using System.Globalization;
using CsvHelper;
using CsvHelper.Configuration;
using PzenaCodeChallenge.Data.Repositories;
using PzenaCodeChallenge.Helpers;
using PzenaCodeChallenge.Models;

namespace PzenaCodeChallenge
{
    public class FileImporter
    {

        private readonly IPriceRepository _priceRepository;
        private readonly ITickerRepository _tickerRepository;

        public FileImporter(IPriceRepository priceRepository, ITickerRepository tickerRepository)
        {
            _priceRepository = priceRepository ?? throw new ArgumentNullException(nameof(priceRepository));
            _tickerRepository = tickerRepository ?? throw new ArgumentNullException(nameof(priceRepository));
        }

        public void ImportPricesFromCsv(string filePath)
        {
            using (var reader = new StreamReader(filePath))
            using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HasHeaderRecord = true,
            }))
            {
                // Use the custom mapping class for case-insensitive mapping
                csv.Context.RegisterClassMap<CaseInsensitivePriceMap>();

                var prices = new List<Price>();
                var lineNumber = 1;

                //NOTE: we cannot just getRecords because any badData will cause issues, log Problem records, and skip 
                //var records = csv.GetRecords<Price>();

                while (csv.Read())
                {
                    try
                    {
                        var price = csv.GetRecord<Price>();
                        prices.Add(price);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error processing line {lineNumber}: {ex.Message}");
                    }
                    finally
                    {
                        lineNumber++;
                    }
                }

                if (prices.Count > 0)
                {
                    _priceRepository.UpsertRange(prices);
                    _priceRepository.SaveChanges();
                    Console.WriteLine("Data inserted into the database successfully.");
                }
                else
                {
                    Console.WriteLine("No valid data found to insert into the database.");
                }
                Console.WriteLine("Data inserted into the database successfully.");
            }
        }


        public void ImportTickersFromCsv(string filePath)
        {
            using (var reader = new StreamReader(filePath))
            using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HasHeaderRecord = true,
            }))
            {
                // Use the custom mapping class for case-insensitive mapping
                csv.Context.RegisterClassMap<CaseInsensitiveTickerMap>();

                var tickers = new List<Ticker>();
                var lineNumber = 1;

                //NOTE: we cannot just getRecords because any badData will cause issues, log Problem records, and skip 
                //var records = csv.GetRecords<Ticker>();

                while (csv.Read())
                {
                    try
                    {
                        var ticker = csv.GetRecord<Ticker>();
                        tickers.Add(ticker);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error processing line {lineNumber}: {ex.Message}");
                    }
                    finally
                    {
                        lineNumber++;
                    }
                }

                if (tickers.Count > 0)
                {
                    _tickerRepository.UpsertRange(tickers);
                    _tickerRepository.SaveChanges();
                    Console.WriteLine("Data inserted into the database successfully.");
                }
                else
                {
                    Console.WriteLine("No valid data found to insert into the database.");
                }

                Console.WriteLine("Data inserted into the database successfully.");
            }
        }
    }
}
