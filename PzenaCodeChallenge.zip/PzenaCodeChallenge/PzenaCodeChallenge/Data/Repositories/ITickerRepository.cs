﻿using PzenaCodeChallenge.Models;

namespace PzenaCodeChallenge.Data.Repositories
{
    public interface ITickerRepository : IDisposable
    {
        void Add(Ticker ticker);
        void AddRange(IEnumerable<Ticker> tickers);
        void UpsertRange(IEnumerable<Ticker> ticker);
        void SaveChanges();
    }
}
