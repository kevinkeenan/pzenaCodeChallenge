﻿using PzenaCodeChallenge.Models;

namespace PzenaCodeChallenge.Data.Repositories
{
    public class PriceRepository : IPriceRepository
    {
        private readonly MyDbContext _dbContext;

        public PriceRepository(MyDbContext dbContext)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        }

        public void Add(Price price)
        {
            _dbContext.Set<Price>().Add(price);
        }

        public void UpsertRange(IEnumerable<Price> prices)
        {
            var batchSize = 500;
            var totalPrices = prices.Count();
            var batches = (int)Math.Ceiling((double)totalPrices / batchSize);

            for (int i = 0; i < batches; i++)
            {
                var batchPrices = prices.Skip(i * batchSize).Take(batchSize);

                foreach (var price in batchPrices)
                {
                    var existingPrice = _dbContext.Price.FirstOrDefault(p => p.Ticker == price.Ticker && p.Date == price.Date);

                    if (existingPrice != null)
                    {
                        // Update existing entity
                        existingPrice.OpenPrice = price.OpenPrice;
                        existingPrice.HighPrice = price.HighPrice;
                        existingPrice.LowPrice = price.LowPrice;
                        existingPrice.ClosePrice = price.ClosePrice;
                        existingPrice.Volume = price.Volume;
                        existingPrice.CloseAdjusted = price.CloseAdjusted;
                        existingPrice.CloseUnadjusted = price.CloseUnadjusted;
                        existingPrice.LastUpdated = price.LastUpdated;
                    }
                    else
                    {
                        _dbContext.Price.Add(price);
                    }
                }

                _dbContext.SaveChanges();
            }
        }

        public void AddRange(IEnumerable<Price> prices)
        {
            _dbContext.Set<Price>().AddRange(prices);
        }

        public void SaveChanges()
        {
            _dbContext.SaveChanges();
        }

        public void Dispose()
        {
            _dbContext.Dispose();
        }
    }
}