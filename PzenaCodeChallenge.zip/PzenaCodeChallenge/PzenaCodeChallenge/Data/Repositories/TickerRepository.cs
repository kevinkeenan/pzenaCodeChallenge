﻿using PzenaCodeChallenge.Models;

namespace PzenaCodeChallenge.Data.Repositories
{
    public class TickerRepository : ITickerRepository
    {
        private readonly MyDbContext _dbContext;

        public TickerRepository(MyDbContext dbContext)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        }

        public void Add(Ticker ticker)
        {
            _dbContext.Set<Ticker>().Add(ticker);
        }

        public void UpsertRange(IEnumerable<Ticker> tickers)
        {
            foreach (var ticker in tickers)
            {
                var existingTicker = _dbContext.Ticker
                    .SingleOrDefault(t => t.TickerSymbol == ticker.TickerSymbol);

                if (existingTicker != null)
                {
                    existingTicker.Table = ticker.Table;
                    existingTicker.PermaTicker = ticker.PermaTicker;
                    existingTicker.Name = ticker.Name;
                    existingTicker.Exchange = ticker.Exchange;
                    existingTicker.IsDelisted = ticker.IsDelisted;
                    existingTicker.Category = ticker.Category;
                    existingTicker.Cusips = ticker.Cusips;
                    existingTicker.SicCode = ticker.SicCode;
                    existingTicker.SicSector = ticker.SicSector;
                    existingTicker.SicIndustry = ticker.SicIndustry;
                    existingTicker.FamaSector = ticker.FamaSector;
                    existingTicker.FamaIndustry = ticker.FamaIndustry;
                    existingTicker.Sector = ticker.Sector;
                    existingTicker.Industry = ticker.Industry;
                    existingTicker.ScaleMarketCap = ticker.ScaleMarketCap;
                    existingTicker.ScaleRevenue = ticker.ScaleRevenue;
                    existingTicker.RelatedTickers = ticker.RelatedTickers;
                    existingTicker.Currency = ticker.Currency;
                    existingTicker.Location = ticker.Location;
                    existingTicker.LastUpdated = ticker.LastUpdated;
                    existingTicker.FirstAdded = ticker.FirstAdded;
                    existingTicker.FirstPriceDate = ticker.FirstPriceDate;
                    existingTicker.LastPriceDate = ticker.LastPriceDate;
                    existingTicker.FirstQuarter = ticker.FirstQuarter;
                    existingTicker.LastQuarter = ticker.LastQuarter;
                    existingTicker.SecFilings = ticker.SecFilings;
                    existingTicker.CompanySite = ticker.CompanySite;
                }
                else
                {
                    _dbContext.Ticker.Add(ticker);
                }
            }

            _dbContext.SaveChanges();
        }

        public void AddRange(IEnumerable<Ticker> tickers)
        {
            _dbContext.Set<Ticker>().AddRange(tickers);
        }

        public void SaveChanges()
        {
            _dbContext.SaveChanges();
        }

        public void Dispose()
        {
            _dbContext.Dispose();
        }
    }
}