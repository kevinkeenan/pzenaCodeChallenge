﻿using PzenaCodeChallenge.Models;

namespace PzenaCodeChallenge.Data.Repositories
{
    public interface IPriceRepository : IDisposable
    {
        void Add(Price price);
        void AddRange(IEnumerable<Price> prices);
        void UpsertRange(IEnumerable<Price> prices);
        void SaveChanges();
    }
}
