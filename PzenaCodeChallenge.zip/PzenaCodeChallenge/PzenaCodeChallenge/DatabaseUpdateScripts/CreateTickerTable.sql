﻿CREATE TABLE Ticker (
    TickerSymbol VARCHAR(10) PRIMARY KEY,
    Permaticker VARCHAR(50) NOT NULL,
    "Table" VARCHAR(50),
    Name VARCHAR(255),
    Exchange VARCHAR(50),
    IsDelisted VARCHAR(1),
    Category VARCHAR(50),
    Cusips VARCHAR(255),
    Siccode INT,
    Sicsector VARCHAR(255),
    Sicindustry VARCHAR(255),
    Famasector VARCHAR(255),
    Famaindustry VARCHAR(255),
    Sector VARCHAR(255),
    Industry VARCHAR(255),
    ScaleMarketCap VARCHAR(255),
    ScaleRevenue VARCHAR(255),
    RelatedTickers VARCHAR(255),
    Currency VARCHAR(10),
    Location VARCHAR(100),
    LastUpdated DATETIME,
    FirstAdded DATETIME,
    FirstPriceDate DATETIME,
    LastPriceDate DATETIME,
    FirstQuarter DATETIME,
    LastQuarter DATETIME,
    SecFilings VARCHAR(255),
    CompanySite VARCHAR(255)
);
CREATE INDEX idx_ticker_symbol ON Ticker (TickerSymbol);
CREATE INDEX idx_exchange ON Ticker (Exchange);
CREATE INDEX idx_last_updated ON Ticker (LastUpdated);