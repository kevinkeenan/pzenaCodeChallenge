﻿CREATE PROCEDURE [CalculateStockInsights]
    @TickerSymbol VARCHAR(10)
AS
BEGIN
DECLARE @StartDate DATE, @EndDate DATE;
SET @EndDate = GETDATE(); -- Current date
SET @StartDate = DATEADD(WEEK, -52, @EndDate); -- 52 weeks ago

-- Calculate 52-day moving average price, 52-week high price, and 52-week low price in a single query
SELECT 
    AVG(CASE WHEN date BETWEEN DATEADD(DAY, -52, @EndDate) AND @EndDate THEN closePrice END) AS '52_Day_Moving_Avg_Price',
    MAX(CASE WHEN date BETWEEN @StartDate AND @EndDate THEN highPrice END) AS '52_Week_High_Price',
    MIN(CASE WHEN date BETWEEN @StartDate AND @EndDate THEN lowPrice END) AS '52_Week_Low_Price'
FROM 
    price
WHERE 
    ticker = @TickerSymbol;

END;
GO

