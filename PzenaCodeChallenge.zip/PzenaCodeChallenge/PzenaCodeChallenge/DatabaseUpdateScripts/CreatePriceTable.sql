﻿CREATE TABLE Price (
    Ticker VARCHAR(10),
    Date DATE,
    OpenPrice DECIMAL(18, 2),
    HighPrice DECIMAL(18, 2),
    LowPrice DECIMAL(18, 2),
    ClosePrice DECIMAL(18, 2),
    Volume DECIMAL(18, 2),
    CloseAdjusted DECIMAL(18, 2),
    CloseUnadjusted DECIMAL(18, 2),
    LastUpdated DATETIME,
    PRIMARY KEY (Ticker, Date)
);

CREATE INDEX idx_ticker ON Price (Ticker);
CREATE INDEX idx_date ON Price (Date);