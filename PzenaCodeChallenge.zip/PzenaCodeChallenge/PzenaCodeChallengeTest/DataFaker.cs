﻿using Bogus;
using AutoBogus;
using PzenaCodeChallenge.Models;

namespace PzenaCodeChallengeTest
{
    public static class DataFaker
    {
        public static Faker<Ticker> Tickers => new AutoFaker<Ticker>()
            .Configure(b => b.WithRecursiveDepth(0))
            .RuleFor(x => x.TickerSymbol, f => f.Random.String(minChar: '3', maxChar: '4'))
            .RuleFor(x => x.PermaTicker, f => f.Random.String(minChar: '5', maxChar: '5'))
            .RuleFor(x => x.Name, f => f.Company.CompanyName())
            .RuleFor(x => x.Exchange, "NASDAQ")
            .RuleFor(x => x.IsDelisted, f => f.PickRandom("Y", "N"))
            .RuleFor(x => x.Category, f => f.Random.String())
            .RuleFor(x => x.Cusips, f => f.Finance.CreditCardNumber())
            .RuleFor(x => x.SicCode, f => f.Random.Int(1000, 9999))
            .RuleFor(x => x.SicIndustry, f => f.Company.CatchPhrase())
            .RuleFor(x => x.FamaIndustry, f => f.Company.CatchPhrase())
            .RuleFor(x => x.ScaleMarketCap, f => f.Commerce.Price(1000, 10000, 0, "$"))
            .RuleFor(x => x.ScaleRevenue, f => f.Commerce.Price(100, 1000, 0, "$"))
            .RuleFor(x => x.RelatedTickers, f => string.Join(",", f.Random.ListItems(new List<string> { "AAPL", "GOOGL", "MSFT" })))
            .RuleFor(x => x.Currency, f => f.Finance.Currency().Code)
            .RuleFor(x => x.Location, f => f.Address.City())
            .RuleFor(x => x.LastUpdated, f => f.Date.Past())
            .RuleFor(x => x.FirstAdded, f => f.Date.Past())
            .RuleFor(x => x.FirstPriceDate, f => f.Date.Past())
            .RuleFor(x => x.LastPriceDate, f => f.Date.Past())
            .RuleFor(x => x.FirstQuarter, f => f.Date.Past())
            .RuleFor(x => x.LastQuarter, f => f.Date.Past())
            .RuleFor(x => x.SecFilings, f => f.Internet.Url())
            .RuleFor(x => x.FamaIndustry, "SomeDummyFamaIndustry")
            .RuleFor(x => x.Table, "SEP")
            .RuleFor(x => x.SicSector, "SomeDummySicSector")
            .RuleFor(x => x.FamaSector, "SomeDummyFamaSector")
            .RuleFor(x => x.Sector, "SomeDummySector")
            .RuleFor(x => x.Industry, "SomeDummyIndustry")
            .RuleFor(x => x.CompanySite, f => f.Internet.Url());
    }
}
