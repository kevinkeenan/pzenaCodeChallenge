using PzenaCodeChallenge;
using PzenaCodeChallenge.Data.Repositories;
using PzenaCodeChallenge.Models;
using Microsoft.EntityFrameworkCore;

namespace PzenaCodeChallengeTest.Repositories
{
    [TestClass]
    public class TickerRepositoryTests
    {
        private MyDbContext _dbContext;
        private TickerRepository _repository;

        [TestInitialize]
        public void TestInitialize()
        {
            var options = new DbContextOptionsBuilder<MyDbContext>()
                .UseInMemoryDatabase("TestDatabase")
                .Options;

            _dbContext = new MyDbContext(options);
            _repository = new TickerRepository(_dbContext);
        }

        [TestCleanup]
        public void TestCleanup()
        {
            _dbContext.Database.EnsureDeleted();
            _dbContext.Dispose();
        }


        [TestMethod]
        public void AddTicker_ShouldSucceed()
        {
            // Arrange 
            var ticker = DataFaker.Tickers
                 .RuleFor(x => x.TickerSymbol, "AAPL")
                 .RuleFor(x => x.PermaTicker, "12345")
                .Generate(1).First();

            // Act
            _repository.Add(ticker);
            _repository.SaveChanges();

            // Assert
            var savedTicker = _dbContext.Ticker.Find(ticker.TickerSymbol);
            Assert.IsNotNull(savedTicker);
        }

        [TestMethod]
        public void UpsertRange_ShouldUpdateExistingTickerAndAddsNewTickerToDbContext()
        {
            // Arrange
            var existingTicker = DataFaker.Tickers
                 .RuleFor(x => x.TickerSymbol, "AAPL")
                 .RuleFor(x => x.PermaTicker, "12345")
                .Generate(1).First();

            var newTicker =
                DataFaker.Tickers
                 .RuleFor(x => x.TickerSymbol, "GOOGL")
                 .RuleFor(x => x.PermaTicker, "12346")
                .Generate(1).First();
            _dbContext.Ticker.Add(existingTicker);
            _dbContext.SaveChanges();

            var tickers = new List<Ticker> { existingTicker, newTicker };

            // Act
            _repository.UpsertRange(tickers);

            // Assert
            var updatedTicker = _dbContext.Ticker.Find(existingTicker.TickerSymbol);
            var addedTicker = _dbContext.Ticker.Find(newTicker.TickerSymbol);
            Assert.IsNotNull(updatedTicker);
            Assert.IsNotNull(addedTicker);
        }

        [TestMethod]
        public void UpsertRange_ShouldUpdateExistingLastPriceDate()
        {
            // Arrange
            var existingTicker = DataFaker.Tickers
                 .RuleFor(x => x.TickerSymbol, "AAPL")
                 .RuleFor(x => x.PermaTicker, "12345")
                 .RuleFor(x => x.LastPriceDate, DateTime.Today)
                .Generate(1).First(); 
            var updatedTicker = DataFaker.Tickers
                 .RuleFor(x => x.TickerSymbol, "AAPL")
                 .RuleFor(x => x.PermaTicker, "12345")
                 .RuleFor(x => x.LastPriceDate, DateTime.Today.AddDays(1))
                .Generate(1).First(); 
            _dbContext.Ticker.Add(existingTicker);
            _dbContext.SaveChanges();

            var tickers = new List<Ticker> { updatedTicker };

            // Act
            _repository.UpsertRange(tickers);

            // Assert
            var newTicker = _dbContext.Ticker.Find(updatedTicker.TickerSymbol);
            Assert.IsNotNull(newTicker);
            Assert.IsTrue(newTicker.LastPriceDate == DateTime.Today.AddDays(1));
        }

        [TestMethod]
        public void AddRange_ShouldAddRangeOfTicketsToDbContext()
        {
            // Arrange
            var tickers = DataFaker.Tickers
                .Generate(3); 

            // Act
            _repository.AddRange(tickers);
            _repository.SaveChanges();

            // Assert
            foreach (var ticker in tickers)
            {
                var savedTicker = _dbContext.Ticker.Find(ticker.TickerSymbol);
                Assert.IsNotNull(savedTicker);
            }
        }
    }
}