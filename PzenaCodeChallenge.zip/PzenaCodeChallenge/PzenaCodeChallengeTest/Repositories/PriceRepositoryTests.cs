using PzenaCodeChallenge;
using PzenaCodeChallenge.Data.Repositories;
using PzenaCodeChallenge.Models;
using Microsoft.EntityFrameworkCore;

namespace PzenaCodeChallengeTest.Repositories
{
    [TestClass]
    public class PriceRepositoryTests
    {
        private MyDbContext _dbContext;
        private PriceRepository _repository;

        [TestInitialize]
        public void TestInitialize()
        {
            var options = new DbContextOptionsBuilder<MyDbContext>()
                .UseInMemoryDatabase("TestDatabase")
                .Options;

            _dbContext = new MyDbContext(options);
            _repository = new PriceRepository(_dbContext);
        }

        [TestCleanup]
        public void TestCleanup()
        {
            _dbContext.Database.EnsureDeleted();
            _dbContext.Dispose();
        }


        [TestMethod]
        public void AddPrice_ShouldSucceed()
        {
            // Arrange 
            var price = new Price { Ticker = "AAPL", Date = DateTime.Today };

            // Act
            _repository.Add(price);
            _repository.SaveChanges();

            // Assert
            var savedPrice = _dbContext.Price.Find(price.Ticker, price.Date);
            Assert.IsNotNull(savedPrice);
        }

        [TestMethod]
        public void UpsertRange_UpdatesExistingPriceAndAddsNewPriceToDbContext()
        {
            // Arrange
            var existingPrice = new Price { Ticker = "AAPL", Date = DateTime.Today};
            var newPrice = new Price { Ticker = "GOOGL", Date = DateTime.Today };
            _dbContext.Price.Add(existingPrice);
            _dbContext.SaveChanges();

            var prices = new List<Price> { newPrice };

            // Act
            _repository.UpsertRange(prices);

            // Assert
            var updatedPrice = _dbContext.Price.Find(existingPrice.Ticker, existingPrice.Date);
            var addedPrice = _dbContext.Price.Find(newPrice.Ticker, newPrice.Date);
            Assert.IsNotNull(updatedPrice);
            Assert.IsNotNull(addedPrice);
        }

        [TestMethod]
        public void UpsertRange_ShouldUpdateExistingPrice()
        {
            // Arrange
            var existingPrice = new Price { Ticker = "AAPL", Date = DateTime.Today, HighPrice = 100 };
            var updatedPrice = new Price { Ticker = "AAPL", Date = DateTime.Today, HighPrice = 2000 };
            _dbContext.Price.Add(existingPrice);
            _dbContext.SaveChanges();

            var prices = new List<Price> { existingPrice, updatedPrice };

            // Act
            _repository.UpsertRange(prices);

            // Assert
            var newPrice = _dbContext.Price.Find(existingPrice.Ticker, existingPrice.Date);
            Assert.IsNotNull(newPrice);
            Assert.IsTrue(newPrice.HighPrice == 2000);
        }

        [TestMethod]
        public void AddRange_AddsRangeOfPricesToDbContext()
        {
            // Arrange
            var prices = new List<Price>
            {
                new Price { Ticker = "AAPL", Date = DateTime.Today },
                new Price { Ticker = "GOOGL", Date = DateTime.Today },
                new Price { Ticker = "MSFT", Date = DateTime.Today }
            };

            // Act
            _repository.AddRange(prices);
            _repository.SaveChanges();

            // Assert
            foreach (var price in prices)
            {
                var savedPrice = _dbContext.Price.Find(price.Ticker, price.Date);
                Assert.IsNotNull(savedPrice);
            }
        }
    }
}